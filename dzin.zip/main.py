import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.widget import Widget 
from kivy.uix.behaviors import ButtonBehavior
from kivy.clock import Clock
from kivy.graphics import *


class ImageButton(ButtonBehavior, Image):
	pass


class Game(GridLayout):

	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.cols = 1



		self.dzin_count = 0


		self.label_goal = Label(text="REACH 1 000 000 DZIN\'S")
		self.add_widget(self.label_goal)


		self.text_layout = GridLayout(cols=2)

		self.label_dzin_count = Label(text="DZIN DZIN")
		self.text_layout.add_widget(self.label_dzin_count)

		self.label_idle_rate = Label(text="IDLE: 0 DZIN'S / s")
		self.text_layout.add_widget(self.label_idle_rate)

		self.add_widget(self.text_layout)

		self.bell_btn = ImageButton(source='./images/bells.png', on_press=self.bell_btn_clicked)
		self.add_widget(self.bell_btn)

		self.btn_layout = GridLayout(cols=2)


		self.dzin_tap = 1
		self.dzin_taps_price = 10
		self.dzin_taps_price_rate = 1.1
		self.btn_dzin_taps = Button(text="+DZIN TAPS\n10")
		self.btn_dzin_taps.bind(on_press=self.btn_dzin_taps_clicked)
		self.btn_layout.add_widget(self.btn_dzin_taps)

		self.idle_dzins = 0

		self.slave_price = 100
		self.slave_price_rate = 1.1
		self.btn_slave = Button(text="SLAVE\n100")
		self.btn_slave.bind(on_press=self.btn_slave_clicked)
		self.btn_layout.add_widget(self.btn_slave)

		self.asm_price = 1000
		self.asm_price_rate = 1.1
		self.btn_bell_asm = Button(text="BELL ASSEMBLER\n1000")
		self.btn_bell_asm.bind(on_press=self.btn_bell_asm_clicked)
		self.btn_layout.add_widget(self.btn_bell_asm)

		self.fact_price = 10000
		self.fact_price_rate = 1.1
		self.btn_bell_fact = Button(text="BELL FACTORY\n10000")
		self.btn_bell_fact.bind(on_press=self.btn_bell_fact_clicked)
		self.btn_layout.add_widget(self.btn_bell_fact)


		self.add_widget(self.btn_layout)

		Clock.schedule_interval(self.real_time_update, 1)


	def real_time_update(self, dt):
		if(self.dzin_count >= 1000000):
			self.label_goal.text = "YOU WIN"
		else:
			self.label_goal.text = "REACH 1 000 000 DZIN\'S"
		self.dzin_count += self.idle_dzins
		self.update_dzin_count()


	def update_dzin_count(self):
		self.label_dzin_count.text = "DZIN'S: " + str(self.dzin_count)

	def update_idle_count(self):
		self.label_idle_rate.text = "IDLE: " + str(self.idle_dzins) + " DZIN'S / s"

	def bell_btn_clicked(self, instance):
		self.dzin_count += self.dzin_tap
		self.label_dzin_count.text = "DZIN'S: " + str(self.dzin_count)

	def btn_dzin_taps_clicked(self, instance):
		if(self.dzin_count >= self.dzin_taps_price):
			self.dzin_count -= self.dzin_taps_price
			self.dzin_tap += 5
			self.dzin_taps_price *= self.dzin_taps_price_rate
			self.dzin_taps_price = int(self.dzin_taps_price)
			self.btn_dzin_taps.text = "+DZIN TAPS\n" + str(self.dzin_taps_price)
			self.update_dzin_count()
		else:
			self.label_goal.text = "NO PESO"


	def btn_slave_clicked(self, instance):
		if(self.dzin_count >= self.slave_price):
			self.dzin_count -= self.slave_price
			self.idle_dzins += 10
			self.slave_price *= self.slave_price_rate
			self.slave_price = int(self.slave_price)
			self.btn_slave.text = "SLAVE\n" + str(self.slave_price)
			self.update_dzin_count()
			self.update_idle_count()
		else:
			self.label_goal.text = "NO PESO"

	def btn_bell_asm_clicked(self, instance):
		if(self.dzin_count >= self.asm_price):
			self.dzin_count -= self.asm_price
			self.idle_dzins += 100
			self.asm_price *= self.asm_price_rate
			self.asm_price = int(self.asm_price)
			self.btn_bell_asm.text = "BELL ASSEMBLER\n" + str(self.asm_price)
			self.update_dzin_count()
			self.update_idle_count()
		else:
			self.label_goal.text = "NO PESO"

	def btn_bell_fact_clicked(self, instance):
		if(self.dzin_count >= self.fact_price):
			self.dzin_count -= self.fact_price
			self.idle_dzins += 1000
			self.fact_price *= self.fact_price_rate
			self.fact_price = int(self.fact_price)
			self.btn_bell_fact.text = "BELL FACTORY\n" + str(self.fact_price)
			self.update_dzin_count()
			self.update_idle_count()
		else:
			self.label_goal.text = "NO PESO"




class DzinApp(App):

	def build(self):
		return Game()


if __name__ == "__main__":
	DzinApp().run()